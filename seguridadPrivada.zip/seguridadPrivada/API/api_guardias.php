<?php
/**
 * Microservicio API REST para Guardias
 * Archivo: API/api_guardias.php
 * Descripción: API REST para operaciones CRUD de guardias
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Incluir configuración
require_once '../config.php';

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Obtener el ID si existe en la URL
$guardia_id = null;
if (isset($path_parts[count($path_parts) - 1]) && is_numeric($path_parts[count($path_parts) - 1])) {
    $guardia_id = intval($path_parts[count($path_parts) - 1]);
}

// Función para enviar respuesta JSON
function sendResponse($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Función para enviar error
function sendError($message, $status_code = 400) {
    sendResponse(['error' => $message], $status_code);
}

// Función para validar datos de entrada
function validateGuardiaData($data) {
    $errors = [];
    
    if (empty($data['codigo_guardia'])) {
        $errors[] = 'El código de guardia es requerido';
    }
    
    if (empty($data['nombre_completo'])) {
        $errors[] = 'El nombre completo es requerido';
    }
    
    if (empty($data['numero_identificacion'])) {
        $errors[] = 'El número de identificación es requerido';
    }
    
    if (empty($data['fecha_ingreso'])) {
        $errors[] = 'La fecha de ingreso es requerida';
    }
    
    if (empty($data['telefono'])) {
        $errors[] = 'El teléfono es requerido';
    }
    
    return $errors;
}

// Procesar solicitudes según el método HTTP
switch ($method) {
    case 'GET':
        if ($guardia_id) {
            // Obtener un guardia específico
            $sql = "SELECT * FROM Guardia WHERE guardia_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $guardia_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $guardia = $result->fetch_assoc();
                sendResponse($guardia);
            } else {
                sendError('Guardia no encontrado', 404);
            }
        } else {
            // Obtener todos los guardias
            $sql = "SELECT * FROM Guardia ORDER BY nombre_completo";
            $result = $conn->query($sql);
            
            $guardias = [];
            while ($row = $result->fetch_assoc()) {
                $guardias[] = $row;
            }
            
            sendResponse(['guardias' => $guardias, 'total' => count($guardias)]);
        }
        break;
        
    case 'POST':
        // Crear nuevo guardia
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        $errors = validateGuardiaData($input);
        if (!empty($errors)) {
            sendError(implode(', ', $errors));
        }
        
        // Verificar si el código ya existe
        $check_sql = "SELECT guardia_id FROM Guardia WHERE codigo_guardia = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $input['codigo_guardia']);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El código de guardia ya existe');
        }
        
        // Verificar si la identificación ya existe
        $check_sql = "SELECT guardia_id FROM Guardia WHERE numero_identificacion = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $input['numero_identificacion']);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El número de identificación ya existe');
        }
        
        $sql = "INSERT INTO Guardia (codigo_guardia, nombre_completo, numero_identificacion, fecha_ingreso, telefono, email) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", 
            $input['codigo_guardia'],
            $input['nombre_completo'],
            $input['numero_identificacion'],
            $input['fecha_ingreso'],
            $input['telefono'],
            $input['email']
        );
        
        if ($stmt->execute()) {
            $guardia_id = $conn->insert_id;
            $input['guardia_id'] = $guardia_id;
            sendResponse($input, 201);
        } else {
            sendError('Error al crear el guardia: ' . $stmt->error, 500);
        }
        break;
        
    case 'PUT':
        // Actualizar guardia existente
        if (!$guardia_id) {
            sendError('ID de guardia requerido', 400);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        $errors = validateGuardiaData($input);
        if (!empty($errors)) {
            sendError(implode(', ', $errors));
        }
        
        // Verificar si el guardia existe
        $check_sql = "SELECT guardia_id FROM Guardia WHERE guardia_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $guardia_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows == 0) {
            sendError('Guardia no encontrado', 404);
        }
        
        // Verificar si el código ya existe en otro guardia
        $check_sql = "SELECT guardia_id FROM Guardia WHERE codigo_guardia = ? AND guardia_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $input['codigo_guardia'], $guardia_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El código de guardia ya existe');
        }
        
        // Verificar si la identificación ya existe en otro guardia
        $check_sql = "SELECT guardia_id FROM Guardia WHERE numero_identificacion = ? AND guardia_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $input['numero_identificacion'], $guardia_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El número de identificación ya existe');
        }
        
        $sql = "UPDATE Guardia SET 
                codigo_guardia = ?, 
                nombre_completo = ?, 
                numero_identificacion = ?, 
                fecha_ingreso = ?, 
                telefono = ?, 
                email = ?,
                estado = ?
                WHERE guardia_id = ?";
        
        $estado = isset($input['estado']) ? $input['estado'] : 'Activo';
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssi", 
            $input['codigo_guardia'],
            $input['nombre_completo'],
            $input['numero_identificacion'],
            $input['fecha_ingreso'],
            $input['telefono'],
            $input['email'],
            $estado,
            $guardia_id
        );
        
        if ($stmt->execute()) {
            $input['guardia_id'] = $guardia_id;
            sendResponse($input);
        } else {
            sendError('Error al actualizar el guardia: ' . $stmt->error, 500);
        }
        break;
        
    case 'DELETE':
        // Eliminar guardia
        if (!$guardia_id) {
            sendError('ID de guardia requerido', 400);
        }
        
        // Verificar si el guardia existe
        $check_sql = "SELECT guardia_id FROM Guardia WHERE guardia_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $guardia_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows == 0) {
            sendError('Guardia no encontrado', 404);
        }
        
        // Verificar si tiene asignaciones activas
        $check_sql = "SELECT asignacion_id FROM Asignacion WHERE guardia_id = ? AND estado = 'Activa'";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $guardia_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('No se puede eliminar el guardia porque tiene asignaciones activas');
        }
        
        $sql = "DELETE FROM Guardia WHERE guardia_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $guardia_id);
        
        if ($stmt->execute()) {
            sendResponse(['message' => 'Guardia eliminado exitosamente']);
        } else {
            sendError('Error al eliminar el guardia: ' . $stmt->error, 500);
        }
        break;
        
    default:
        sendError('Método no permitido', 405);
        break;
}
?>

<?php
/**
 * Microservicio API REST para Servicios
 * Archivo: API/api_servicios.php
 * Descripción: API REST para operaciones CRUD de servicios
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Incluir configuración
require_once '../config.php';

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Obtener el ID si existe en la URL
$servicio_id = null;
if (isset($path_parts[count($path_parts) - 1]) && is_numeric($path_parts[count($path_parts) - 1])) {
    $servicio_id = intval($path_parts[count($path_parts) - 1]);
}

// Función para enviar respuesta JSON
function sendResponse($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Función para enviar error
function sendError($message, $status_code = 400) {
    sendResponse(['error' => $message], $status_code);
}

// Función para validar datos de entrada
function validateServicioData($data) {
    $errors = [];
    
    if (empty($data['codigo_servicio'])) {
        $errors[] = 'El código de servicio es requerido';
    }
    
    if (empty($data['nombre'])) {
        $errors[] = 'El nombre del servicio es requerido';
    }
    
    if (empty($data['descripcion'])) {
        $errors[] = 'La descripción es requerida';
    }
    
    if (!isset($data['tarifa_mensual']) || $data['tarifa_mensual'] <= 0) {
        $errors[] = 'La tarifa mensual debe ser mayor a 0';
    }
    
    if (empty($data['cliente_id'])) {
        $errors[] = 'El cliente es requerido';
    }
    
    return $errors;
}

// Procesar solicitudes según el método HTTP
switch ($method) {
    case 'GET':
        if ($servicio_id) {
            // Obtener un servicio específico
            $sql = "SELECT s.*, c.nombre as cliente_nombre 
                    FROM Servicio s 
                    LEFT JOIN Cliente c ON s.cliente_id = c.cliente_id 
                    WHERE s.servicio_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $servicio_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $servicio = $result->fetch_assoc();
                sendResponse($servicio);
            } else {
                sendError('Servicio no encontrado', 404);
            }
        } else {
            // Obtener todos los servicios
            $sql = "SELECT s.*, c.nombre as cliente_nombre 
                    FROM Servicio s 
                    LEFT JOIN Cliente c ON s.cliente_id = c.cliente_id 
                    ORDER BY s.nombre";
            $result = $conn->query($sql);
            
            $servicios = [];
            while ($row = $result->fetch_assoc()) {
                $servicios[] = $row;
            }
            
            sendResponse(['servicios' => $servicios, 'total' => count($servicios)]);
        }
        break;
        
    case 'POST':
        // Crear nuevo servicio
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        $errors = validateServicioData($input);
        if (!empty($errors)) {
            sendError(implode(', ', $errors));
        }
        
        // Verificar si el código ya existe
        $check_sql = "SELECT servicio_id FROM Servicio WHERE codigo_servicio = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $input['codigo_servicio']);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El código de servicio ya existe');
        }
        
        $sql = "INSERT INTO Servicio (codigo_servicio, nombre, descripcion, tarifa_mensual, cliente_id) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdi", 
            $input['codigo_servicio'],
            $input['nombre'],
            $input['descripcion'],
            $input['tarifa_mensual'],
            $input['cliente_id']
        );
        
        if ($stmt->execute()) {
            $servicio_id = $conn->insert_id;
            $input['servicio_id'] = $servicio_id;
            sendResponse($input, 201);
        } else {
            sendError('Error al crear el servicio: ' . $stmt->error, 500);
        }
        break;
        
    case 'PUT':
        // Actualizar servicio existente
        if (!$servicio_id) {
            sendError('ID de servicio requerido', 400);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        $errors = validateServicioData($input);
        if (!empty($errors)) {
            sendError(implode(', ', $errors));
        }
        
        // Verificar si el servicio existe
        $check_sql = "SELECT servicio_id FROM Servicio WHERE servicio_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $servicio_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows == 0) {
            sendError('Servicio no encontrado', 404);
        }
        
        // Verificar si el código ya existe en otro servicio
        $check_sql = "SELECT servicio_id FROM Servicio WHERE codigo_servicio = ? AND servicio_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $input['codigo_servicio'], $servicio_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            sendError('El código de servicio ya existe');
        }
        
        $sql = "UPDATE Servicio SET 
                codigo_servicio = ?, 
                nombre = ?, 
                descripcion = ?, 
                tarifa_mensual = ?,
                cliente_id = ?,
                estado = ?
                WHERE servicio_id = ?";
        
        $estado = isset($input['estado']) ? $input['estado'] : 'Activo';
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdisi", 
            $input['codigo_servicio'],
            $input['nombre'],
            $input['descripcion'],
            $input['tarifa_mensual'],
            $input['cliente_id'],
            $estado,
            $servicio_id
        );
        
        if ($stmt->execute()) {
            $input['servicio_id'] = $servicio_id;
            sendResponse($input);
        } else {
            sendError('Error al actualizar el servicio: ' . $stmt->error, 500);
        }
        break;
        
    case 'DELETE':
        // Eliminar servicio
        if (!$servicio_id) {
            sendError('ID de servicio requerido', 400);
        }
        
        // Verificar si el servicio existe
        $check_sql = "SELECT servicio_id FROM Servicio WHERE servicio_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $servicio_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows == 0) {
            sendError('Servicio no encontrado', 404);
        }
        
        $sql = "DELETE FROM Servicio WHERE servicio_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $servicio_id);
        
        if ($stmt->execute()) {
            sendResponse(['message' => 'Servicio eliminado exitosamente']);
        } else {
            sendError('Error al eliminar el servicio: ' . $stmt->error, 500);
        }
        break;
        
    default:
        sendError('Método no permitido', 405);
        break;
}
?>

<?php
/**
 * Microservicio API REST para Asignaciones
 * Archivo: API/api_asignaciones.php
 * Descripción: API REST para operaciones CRUD de asignaciones de guardias
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Incluir configuración
require_once '../config.php';

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Obtener el ID si existe en la URL
$asignacion_id = null;
if (isset($path_parts[count($path_parts) - 1]) && is_numeric($path_parts[count($path_parts) - 1])) {
    $asignacion_id = intval($path_parts[count($path_parts) - 1]);
}

// Función para enviar respuesta JSON
function sendResponse($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Función para enviar error
function sendError($message, $status_code = 400) {
    sendResponse(['error' => $message], $status_code);
}

// Función para validar datos de entrada
function validateAsignacionData($data) {
    $errors = [];
    
    if (empty($data['guardia_id'])) {
        $errors[] = 'El ID del guardia es requerido';
    }
    
    if (empty($data['turno_id'])) {
        $errors[] = 'El ID del turno es requerido';
    }
    
    if (empty($data['zona_id'])) {
        $errors[] = 'El ID de la zona es requerido';
    }
    
    if (empty($data['fecha_asignacion'])) {
        $errors[] = 'La fecha de asignación es requerida';
    }
    
    return $errors;
}

// Procesar solicitudes según el método HTTP
switch ($method) {
    case 'GET':
        if ($asignacion_id) {
            // Obtener una asignación específica con información relacionada
            $sql = "SELECT a.*, g.nombre_completo as guardia_nombre, t.nombre_turno, z.nombre_zona 
                    FROM Asignacion a 
                    JOIN Guardia g ON a.guardia_id = g.guardia_id 
                    JOIN Turno t ON a.turno_id = t.turno_id 
                    JOIN Zona z ON a.zona_id = z.zona_id 
                    WHERE a.asignacion_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $asignacion_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $asignacion = $result->fetch_assoc();
                sendResponse($asignacion);
            } else {
                sendError('Asignación no encontrada', 404);
            }
        } else {
            // Obtener todas las asignaciones con información relacionada
            $sql = "SELECT a.*, g.nombre_completo as guardia_nombre, t.nombre_turno, z.nombre_zona 
                    FROM Asignacion a 
                    JOIN Guardia g ON a.guardia_id = g.guardia_id 
                    JOIN Turno t ON a.turno_id = t.turno_id 
                    JOIN Zona z ON a.zona_id = z.zona_id 
                    ORDER BY a.fecha_asignacion DESC";
            $result = $conn->query($sql);
            
            $asignaciones = [];
            while ($row = $result->fetch_assoc()) {
                $asignaciones[] = $row;
            }
            
            sendResponse(['asignaciones' => $asignaciones, 'total' => count($asignaciones)]);
        }
        break;
        
    case 'POST':
        // Crear nueva asignación
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        $errors = validateAsignacionData($input);
        if (!empty($errors)) {
            sendError(implode(', ', $errors));
        }
        
        // Verificar que el guardia, turno y zona existen
        $guardia_id = intval($input['guardia_id']);
        $turno_id = intval($input['turno_id']);
        $zona_id = intval($input['zona_id']);
        
        // Verificar guardia
        $stmt = $conn->prepare("SELECT guardia_id FROM Guardia WHERE guardia_id = ?");
        $stmt->bind_param("i", $guardia_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            sendError('El guardia especificado no existe');
        }
        
        // Verificar turno
        $stmt = $conn->prepare("SELECT turno_id FROM Turno WHERE turno_id = ?");
        $stmt->bind_param("i", $turno_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            sendError('El turno especificado no existe');
        }
        
        // Verificar zona
        $stmt = $conn->prepare("SELECT zona_id FROM Zona WHERE zona_id = ?");
        $stmt->bind_param("i", $zona_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            sendError('La zona especificada no existe');
        }
        
        // Verificar si ya existe una asignación para este guardia en la misma fecha
        $fecha_asignacion = $input['fecha_asignacion'];
        $stmt = $conn->prepare("SELECT asignacion_id FROM Asignacion WHERE guardia_id = ? AND fecha_asignacion = ?");
        $stmt->bind_param("is", $guardia_id, $fecha_asignacion);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            sendError('Ya existe una asignación para este guardia en la fecha especificada');
        }
        
        // Insertar nueva asignación
        $sql = "INSERT INTO Asignacion (guardia_id, turno_id, zona_id, fecha_asignacion, estado) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $estado = isset($input['estado']) ? $input['estado'] : 'Activa';
        $stmt->bind_param("iiiss", $guardia_id, $turno_id, $zona_id, $fecha_asignacion, $estado);
        
        if ($stmt->execute()) {
            $nueva_asignacion_id = $conn->insert_id;
            
            // Obtener la asignación creada con información relacionada
            $sql = "SELECT a.*, g.nombre_completo as guardia_nombre, t.nombre_turno, z.nombre_zona 
                    FROM Asignacion a 
                    JOIN Guardia g ON a.guardia_id = g.guardia_id 
                    JOIN Turno t ON a.turno_id = t.turno_id 
                    JOIN Zona z ON a.zona_id = z.zona_id 
                    WHERE a.asignacion_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $nueva_asignacion_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $asignacion = $result->fetch_assoc();
            
            sendResponse([
                'message' => 'Asignación creada exitosamente',
                'asignacion' => $asignacion
            ], 201);
        } else {
            sendError('Error al crear la asignación: ' . $conn->error, 500);
        }
        break;
        
    case 'PUT':
        // Actualizar asignación existente
        if (!$asignacion_id) {
            sendError('ID de asignación requerido para actualización', 400);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Datos JSON inválidos');
        }
        
        // Verificar que la asignación existe
        $stmt = $conn->prepare("SELECT asignacion_id FROM Asignacion WHERE asignacion_id = ?");
        $stmt->bind_param("i", $asignacion_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            sendError('Asignación no encontrada', 404);
        }
        
        // Construir query de actualización dinámicamente
        $update_fields = [];
        $types = '';
        $values = [];
        
        if (isset($input['guardia_id'])) {
            $update_fields[] = "guardia_id = ?";
            $types .= 'i';
            $values[] = intval($input['guardia_id']);
        }
        
        if (isset($input['turno_id'])) {
            $update_fields[] = "turno_id = ?";
            $types .= 'i';
            $values[] = intval($input['turno_id']);
        }
        
        if (isset($input['zona_id'])) {
            $update_fields[] = "zona_id = ?";
            $types .= 'i';
            $values[] = intval($input['zona_id']);
        }
        
        if (isset($input['fecha_asignacion'])) {
            $update_fields[] = "fecha_asignacion = ?";
            $types .= 's';
            $values[] = $input['fecha_asignacion'];
        }
        
        if (isset($input['estado'])) {
            $update_fields[] = "estado = ?";
            $types .= 's';
            $values[] = $input['estado'];
        }
        
        if (empty($update_fields)) {
            sendError('No se proporcionaron campos para actualizar');
        }
        
        $sql = "UPDATE Asignacion SET " . implode(', ', $update_fields) . " WHERE asignacion_id = ?";
        $types .= 'i';
        $values[] = $asignacion_id;
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$values);
        
        if ($stmt->execute()) {
            // Obtener la asignación actualizada
            $sql = "SELECT a.*, g.nombre_completo as guardia_nombre, t.nombre_turno, z.nombre_zona 
                    FROM Asignacion a 
                    JOIN Guardia g ON a.guardia_id = g.guardia_id 
                    JOIN Turno t ON a.turno_id = t.turno_id 
                    JOIN Zona z ON a.zona_id = z.zona_id 
                    WHERE a.asignacion_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $asignacion_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $asignacion = $result->fetch_assoc();
            
            sendResponse([
                'message' => 'Asignación actualizada exitosamente',
                'asignacion' => $asignacion
            ]);
        } else {
            sendError('Error al actualizar la asignación: ' . $conn->error, 500);
        }
        break;
        
    case 'DELETE':
        // Eliminar asignación
        if (!$asignacion_id) {
            sendError('ID de asignación requerido para eliminación', 400);
        }
        
        // Verificar que la asignación existe
        $stmt = $conn->prepare("SELECT asignacion_id FROM Asignacion WHERE asignacion_id = ?");
        $stmt->bind_param("i", $asignacion_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            sendError('Asignación no encontrada', 404);
        }
        
        // Eliminar la asignación
        $sql = "DELETE FROM Asignacion WHERE asignacion_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $asignacion_id);
        
        if ($stmt->execute()) {
            sendResponse(['message' => 'Asignación eliminada exitosamente']);
        } else {
            sendError('Error al eliminar la asignación: ' . $conn->error, 500);
        }
        break;
        
    default:
        sendError('Método HTTP no soportado', 405);
        break;
}

$conn->close();
?>

<?php
/**
 * Configuración de la base de datos para el Sistema de Seguridad Privada
 * Archivo: config.php
 * Descripción: Establece la conexión con la base de datos MySQL usando mysqli
 */

// Configuración de la base de datos
$servername = "localhost";
$username = "root"; // Usuario por defecto de XAMPP
$password = "";     // Contraseña por defecto de XAMPP
$dbname = "SeguridadDB";

// Crear conexión usando mysqli
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Configurar charset para evitar problemas con caracteres especiales
$conn->set_charset("utf8");

// Función para limpiar datos de entrada
function limpiarDatos($datos) {
    global $conn;
    return $conn->real_escape_string(trim($datos));
}

// Función para verificar si el usuario tiene permisos
function tienePermiso($rol, $accion, $tabla) {
    $matrizPermisos = [
        'Administrador' => [
            'Cliente' => ['C', 'R', 'U', 'D'],
            'Servicio' => ['C', 'R', 'U', 'D'],
            'Turno' => ['C', 'R', 'U', 'D'],
            'Zona' => ['C', 'R', 'U', 'D'],
            'Supervisor' => ['C', 'R', 'U', 'D'],
            'Guardia' => ['C', 'R', 'U', 'D'],
            'Asignacion' => ['C', 'R', 'U', 'D'],
            'Usuario' => ['C', 'R', 'U', 'D']
        ],
        'Desarrollador' => [
            'Guardia' => ['C', 'R', 'U', 'D'],
            'Asignacion' => ['C', 'R', 'U', 'D'],
            'Turno' => ['C', 'R', 'U', 'D'],
            'Cliente' => ['R'],
            'Servicio' => ['R'],
            'Zona' => ['R'],
            'Supervisor' => ['R']
        ],
        'Supervisor' => [
            'Guardia' => ['R'],
            'Asignacion' => ['R'],
            'Turno' => ['R'],
            'Cliente' => ['R'],
            'Servicio' => ['R'],
            'Zona' => ['R'],
            'Supervisor' => ['R']
        ]
    ];
    
    return isset($matrizPermisos[$rol][$tabla]) && in_array($accion, $matrizPermisos[$rol][$tabla]);
}

// Función para obtener el nombre del rol en español
function obtenerNombreRol($rol) {
    $roles = [
        'Administrador' => 'Administrador',
        'Desarrollador' => 'Desarrollador',
        'Supervisor' => 'Supervisor'
    ];
    
    return isset($roles[$rol]) ? $roles[$rol] : $rol;
}
?> 
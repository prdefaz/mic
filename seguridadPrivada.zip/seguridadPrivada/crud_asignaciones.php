<?php
/**
 * CRUD de Asignaciones - Sistema de Seguridad Privada
 * Archivo: crud_asignaciones.php
 * Descripción: Gestión completa de asignaciones de guardias
 */

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir configuración
require_once 'config.php';

$rol = $_SESSION['rol'];

// Verificar permisos
if (!tienePermiso($rol, 'R', 'Asignacion')) {
    header("Location: index.php");
    exit();
}

$mensaje = '';
$tipo_mensaje = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {
            case 'crear':
                if (tienePermiso($rol, 'C', 'Asignacion')) {
                    $codigo = limpiarDatos($_POST['codigo_asignacion']);
                    $guardia_id = limpiarDatos($_POST['guardia_id']);
                    $turno_id = limpiarDatos($_POST['turno_id']);
                    $zona_id = limpiarDatos($_POST['zona_id']);
                    $supervisor_id = limpiarDatos($_POST['supervisor_id']);
                    $fecha_inicio = limpiarDatos($_POST['fecha_inicio']);
                    $fecha_fin = limpiarDatos($_POST['fecha_fin']);
                    $observaciones = limpiarDatos($_POST['observaciones']);
                    
                    $sql = "INSERT INTO Asignacion (codigo_asignacion, guardia_id, turno_id, zona_id, supervisor_id, fecha_inicio, fecha_fin, observaciones) 
                            VALUES ('$codigo', $guardia_id, $turno_id, $zona_id, $supervisor_id, '$fecha_inicio', '$fecha_fin', '$observaciones')";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Asignación creada exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al crear asignación: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'actualizar':
                if (tienePermiso($rol, 'U', 'Asignacion')) {
                    $id = limpiarDatos($_POST['asignacion_id']);
                    $codigo = limpiarDatos($_POST['codigo_asignacion']);
                    $guardia_id = limpiarDatos($_POST['guardia_id']);
                    $turno_id = limpiarDatos($_POST['turno_id']);
                    $zona_id = limpiarDatos($_POST['zona_id']);
                    $supervisor_id = limpiarDatos($_POST['supervisor_id']);
                    $fecha_inicio = limpiarDatos($_POST['fecha_inicio']);
                    $fecha_fin = limpiarDatos($_POST['fecha_fin']);
                    $observaciones = limpiarDatos($_POST['observaciones']);
                    $estado = limpiarDatos($_POST['estado']);
                    
                    $sql = "UPDATE Asignacion SET 
                            codigo_asignacion = '$codigo',
                            guardia_id = $guardia_id,
                            turno_id = $turno_id,
                            zona_id = $zona_id,
                            supervisor_id = $supervisor_id,
                            fecha_inicio = '$fecha_inicio',
                            fecha_fin = '$fecha_fin',
                            observaciones = '$observaciones',
                            estado = '$estado'
                            WHERE asignacion_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Asignación actualizada exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al actualizar asignación: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'eliminar':
                if (tienePermiso($rol, 'D', 'Asignacion')) {
                    $id = limpiarDatos($_POST['asignacion_id']);
                    
                    $sql = "DELETE FROM Asignacion WHERE asignacion_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Asignación eliminada exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al eliminar asignación: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
        }
    }
}

// Obtener datos para editar
$asignacion_editar = null;
if (isset($_GET['editar']) && tienePermiso($rol, 'U', 'Asignacion')) {
    $id = limpiarDatos($_GET['editar']);
    $result = $conn->query("SELECT * FROM Asignacion WHERE asignacion_id = $id");
    if ($result->num_rows > 0) {
        $asignacion_editar = $result->fetch_assoc();
    }
}

// Obtener listas para los selects
$guardias_result = $conn->query("SELECT guardia_id, nombre_completo FROM Guardia WHERE estado = 'Activo' ORDER BY nombre_completo");
$turnos_result = $conn->query("SELECT turno_id, codigo_turno, hora_inicio, hora_fin FROM Turno WHERE estado = 'Activo' ORDER BY hora_inicio");
$zonas_result = $conn->query("SELECT zona_id, nombre FROM Zona WHERE estado = 'Activo' ORDER BY nombre");
$supervisores_result = $conn->query("SELECT supervisor_id, nombre_completo FROM Supervisor WHERE estado = 'Activo' ORDER BY nombre_completo");

// Obtener lista de asignaciones con joins
$sql = "SELECT a.*, 
               g.nombre_completo as guardia_nombre,
               t.codigo_turno, t.hora_inicio, t.hora_fin,
               z.nombre as zona_nombre,
               s.nombre_completo as supervisor_nombre
        FROM Asignacion a 
        LEFT JOIN Guardia g ON a.guardia_id = g.guardia_id 
        LEFT JOIN Turno t ON a.turno_id = t.turno_id 
        LEFT JOIN Zona z ON a.zona_id = z.zona_id 
        LEFT JOIN Supervisor s ON a.supervisor_id = s.supervisor_id 
        ORDER BY a.fecha_asignacion DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Asignaciones - Sistema de Seguridad</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            color: #333;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }
        
        .back-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #2c3e50;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.3s ease;
        }
        
        .btn-primary {
            background: #2c3e50;
            color: white;
        }
        
        .btn-primary:hover {
            background: #34495e;
        }
        
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .table-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .table-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .status-activa {
            color: #27ae60;
            font-weight: 600;
        }
        
        .status-finalizada {
            color: #e74c3c;
            font-weight: 600;
        }
        
        .status-suspendida {
            color: #f39c12;
            font-weight: 600;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }
        
        .mensaje {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .mensaje.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .mensaje.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .assignment-info {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .date-range {
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>📋 Gestionar Asignaciones</h1>
            <a href="index.php" class="back-btn">← Volver al Dashboard</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
        <?php endif; ?>
        
        <?php if (tienePermiso($rol, 'C', 'Asignacion') || tienePermiso($rol, 'U', 'Asignacion')): ?>
        <div class="form-section">
            <h2><?php echo $asignacion_editar ? 'Editar Asignación' : 'Crear Nueva Asignación'; ?></h2>
            <form method="POST">
                <input type="hidden" name="accion" value="<?php echo $asignacion_editar ? 'actualizar' : 'crear'; ?>">
                <?php if ($asignacion_editar): ?>
                <input type="hidden" name="asignacion_id" value="<?php echo $asignacion_editar['asignacion_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="codigo_asignacion">Código de Asignación:</label>
                        <input type="text" id="codigo_asignacion" name="codigo_asignacion" 
                               value="<?php echo $asignacion_editar ? htmlspecialchars($asignacion_editar['codigo_asignacion']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="guardia_id">Guardia:</label>
                        <select id="guardia_id" name="guardia_id" required>
                            <option value="">Seleccionar guardia</option>
                            <?php while($guardia = $guardias_result->fetch_assoc()): ?>
                            <option value="<?php echo $guardia['guardia_id']; ?>" 
                                    <?php echo ($asignacion_editar && $asignacion_editar['guardia_id'] == $guardia['guardia_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($guardia['nombre_completo']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="turno_id">Turno:</label>
                        <select id="turno_id" name="turno_id" required>
                            <option value="">Seleccionar turno</option>
                            <?php while($turno = $turnos_result->fetch_assoc()): ?>
                            <option value="<?php echo $turno['turno_id']; ?>" 
                                    <?php echo ($asignacion_editar && $asignacion_editar['turno_id'] == $turno['turno_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($turno['codigo_turno'] . ' (' . $turno['hora_inicio'] . '-' . $turno['hora_fin'] . ')'); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="zona_id">Zona:</label>
                        <select id="zona_id" name="zona_id" required>
                            <option value="">Seleccionar zona</option>
                            <?php while($zona = $zonas_result->fetch_assoc()): ?>
                            <option value="<?php echo $zona['zona_id']; ?>" 
                                    <?php echo ($asignacion_editar && $asignacion_editar['zona_id'] == $zona['zona_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($zona['nombre']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="supervisor_id">Supervisor:</label>
                        <select id="supervisor_id" name="supervisor_id" required>
                            <option value="">Seleccionar supervisor</option>
                            <?php while($supervisor = $supervisores_result->fetch_assoc()): ?>
                            <option value="<?php echo $supervisor['supervisor_id']; ?>" 
                                    <?php echo ($asignacion_editar && $asignacion_editar['supervisor_id'] == $supervisor['supervisor_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($supervisor['nombre_completo']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_inicio">Fecha de Inicio:</label>
                        <input type="date" id="fecha_inicio" name="fecha_inicio" 
                               value="<?php echo $asignacion_editar ? $asignacion_editar['fecha_inicio'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_fin">Fecha de Fin:</label>
                        <input type="date" id="fecha_fin" name="fecha_fin" 
                               value="<?php echo $asignacion_editar ? $asignacion_editar['fecha_fin'] : ''; ?>" 
                               required>
                    </div>
                    
                    <?php if ($asignacion_editar): ?>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select id="estado" name="estado" required>
                            <option value="Activa" <?php echo $asignacion_editar['estado'] == 'Activa' ? 'selected' : ''; ?>>Activa</option>
                            <option value="Finalizada" <?php echo $asignacion_editar['estado'] == 'Finalizada' ? 'selected' : ''; ?>>Finalizada</option>
                            <option value="Suspendida" <?php echo $asignacion_editar['estado'] == 'Suspendida' ? 'selected' : ''; ?>>Suspendida</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label for="observaciones">Observaciones:</label>
                    <textarea id="observaciones" name="observaciones"><?php echo $asignacion_editar ? htmlspecialchars($asignacion_editar['observaciones']) : ''; ?></textarea>
                </div>
                
                <div style="margin-top: 20px;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $asignacion_editar ? 'Actualizar Asignación' : 'Crear Asignación'; ?>
                    </button>
                    <?php if ($asignacion_editar): ?>
                    <a href="crud_asignaciones.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="table-section">
            <h2>Lista de Asignaciones</h2>
            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Guardia</th>
                        <th>Turno</th>
                        <th>Zona</th>
                        <th>Supervisor</th>
                        <th>Período</th>
                        <th>Estado</th>
                        <?php if (tienePermiso($rol, 'U', 'Asignacion') || tienePermiso($rol, 'D', 'Asignacion')): ?>
                        <th>Acciones</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="assignment-info"><?php echo htmlspecialchars($row['codigo_asignacion']); ?></td>
                            <td><?php echo htmlspecialchars($row['guardia_nombre']); ?></td>
                            <td><?php echo htmlspecialchars($row['codigo_turno'] . ' (' . $row['hora_inicio'] . '-' . $row['hora_fin'] . ')'); ?></td>
                            <td><?php echo htmlspecialchars($row['zona_nombre']); ?></td>
                            <td><?php echo htmlspecialchars($row['supervisor_nombre']); ?></td>
                            <td>
                                <div class="date-range">
                                    <?php echo $row['fecha_inicio']; ?> - <?php echo $row['fecha_fin']; ?>
                                </div>
                            </td>
                            <td>
                                <span class="status-<?php echo strtolower($row['estado']); ?>">
                                    <?php echo $row['estado']; ?>
                                </span>
                            </td>
                            <?php if (tienePermiso($rol, 'U', 'Asignacion') || tienePermiso($rol, 'D', 'Asignacion')): ?>
                            <td>
                                <div class="action-buttons">
                                    <?php if (tienePermiso($rol, 'U', 'Asignacion')): ?>
                                    <a href="?editar=<?php echo $row['asignacion_id']; ?>" class="btn btn-secondary btn-small">Editar</a>
                                    <?php endif; ?>
                                    <?php if (tienePermiso($rol, 'D', 'Asignacion')): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('¿Está seguro de eliminar esta asignación?');">
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="asignacion_id" value="<?php echo $row['asignacion_id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-small">Eliminar</button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: #666;">No hay asignaciones registradas</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

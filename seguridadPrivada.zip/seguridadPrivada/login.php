<?php
/**
 * Página de Login del Sistema Bancario
 * Archivo: login.php
 * Descripción: Autenticación de usuarios con validación segura
 */

session_start();

// Si ya está logueado, redirigir al index
if (isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit();
}

// Incluir configuración de base de datos
require_once 'config.php';

$error = '';

// Procesar formulario de login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'Por favor, complete todos los campos.';
    } else {
        // Usar declaración preparada para prevenir inyección SQL
        $stmt = $conn->prepare("SELECT usuario_id, username, password_hash, rol FROM Usuario WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $usuario = $result->fetch_assoc();
            
            // Verificar contraseña usando password_verify
            if (password_verify($password, $usuario['password_hash'])) {
                // Login exitoso - crear sesión
                $_SESSION['usuario_id'] = $usuario['usuario_id'];
                $_SESSION['username'] = $usuario['username'];
                $_SESSION['rol'] = $usuario['rol'];
                $_SESSION['ultimo_acceso'] = date('Y-m-d H:i:s');
                
                // Actualizar último acceso en la base de datos
                $update_stmt = $conn->prepare("UPDATE Usuario SET ultimo_acceso = ? WHERE usuario_id = ?");
                $update_stmt->bind_param("si", $_SESSION['ultimo_acceso'], $usuario['usuario_id']);
                $update_stmt->execute();
                
                header("Location: index.php");
                exit();
            } else {
                $error = 'Credenciales incorrectas.';
            }
        } else {
            $error = 'Credenciales incorrectas.';
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Seguridad Privada</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 50px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
            border: 1px solid rgba(5, 150, 105, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, #059669 0%, #f59e0b 100%);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .login-header h1 {
            color: #059669;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(5, 150, 105, 0.1);
        }
        
        .login-header p {
            color: #64748b;
            font-size: 16px;
            line-height: 1.5;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #374151;
            font-weight: 600;
            font-size: 14px;
        }
        
        .form-group input {
            width: 100%;
            padding: 15px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1f2937;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #059669;
            box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
            transform: translateY(-2px);
        }
        
        .form-group input::placeholder {
            color: #9ca3af;
        }
        
        .login-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 16px rgba(5, 150, 105, 0.3);
            margin-bottom: 20px;
        }
        
        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(5, 150, 105, 0.4);
        }
        
        .login-btn:active {
            transform: translateY(-1px);
        }
        
        .error-message {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            font-weight: 500;
            text-align: center;
            box-shadow: 0 4px 16px rgba(239, 68, 68, 0.3);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .demo-credentials {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border: 1px solid #f59e0b;
            padding: 20px;
            border-radius: 12px;
            margin-top: 30px;
        }
        
        .demo-credentials h3 {
            color: #92400e;
            font-size: 16px;
            margin-bottom: 15px;
            font-weight: 600;
        }
        
        .demo-credentials p {
            color: #92400e;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .demo-credentials strong {
            color: #059669;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }
            
            .login-container {
                padding: 40px 30px;
                border-radius: 16px;
            }
            
            .login-header h1 {
                font-size: 28px;
            }
            
            .login-header p {
                font-size: 15px;
            }
            
            .form-group input {
                padding: 14px 16px;
                font-size: 15px;
            }
            
            .login-btn {
                padding: 15px;
                font-size: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 25px;
                border-radius: 12px;
            }
            
            .login-header h1 {
                font-size: 24px;
            }
            
            .login-header p {
                font-size: 14px;
            }
            
            .form-group {
                margin-bottom: 20px;
            }
            
            .form-group input {
                padding: 12px 14px;
                font-size: 14px;
            }
            
            .login-btn {
                padding: 14px;
                font-size: 14px;
            }
            
            .demo-credentials {
                padding: 15px;
                margin-top: 25px;
            }
            
            .demo-credentials h3 {
                font-size: 15px;
            }
            
            .demo-credentials p {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Sistema de Seguridad Privada</h1>
            <p>Inicie sesión para continuar</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Usuario:</label>
                <input type="text" id="username" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-btn">Iniciar Sesión</button>
        </form>
    </div>
</body>
</html> 
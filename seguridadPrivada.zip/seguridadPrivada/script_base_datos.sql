-- =====================================================
-- SCRIPT DE BASE DE DATOS - SISTEMA DE SEGURIDAD PRIVADA
-- Archivo: script_base_datos.sql
-- Descripción: Script completo para crear la base de datos SeguridadDB
-- =====================================================

-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS SeguridadDB;
USE SeguridadDB;

-- =====================================================
-- CREACIÓN DE TABLAS
-- =====================================================

-- Tabla de Clientes
CREATE TABLE Cliente (
    cliente_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_cliente VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(200) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    fecha_registro DATE NOT NULL DEFAULT CURRENT_DATE,
    estado ENUM('Activo', 'Inactivo') NOT NULL DEFAULT 'Activo'
);

-- Tabla de Servicios
CREATE TABLE Servicio (
    servicio_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_servicio VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    tarifa_mensual DECIMAL(10,2) NOT NULL,
    cliente_id INT NOT NULL,
    fecha_contratacion DATE NOT NULL DEFAULT CURRENT_DATE,
    estado ENUM('Activo', 'Inactivo', 'Suspendido') NOT NULL DEFAULT 'Activo',
    FOREIGN KEY (cliente_id) REFERENCES Cliente(cliente_id) ON DELETE CASCADE
);

-- Tabla de Turnos
CREATE TABLE Turno (
    turno_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_turno VARCHAR(20) UNIQUE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    tipo_turno ENUM('Diurno', 'Nocturno') NOT NULL,
    descripcion VARCHAR(200),
    estado ENUM('Activo', 'Inactivo') NOT NULL DEFAULT 'Activo'
);

-- Tabla de Zonas
CREATE TABLE Zona (
    zona_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_zona VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(200) NOT NULL,
    cliente_id INT NOT NULL,
    descripcion TEXT,
    estado ENUM('Activa', 'Inactiva') NOT NULL DEFAULT 'Activa',
    FOREIGN KEY (cliente_id) REFERENCES Cliente(cliente_id) ON DELETE CASCADE
);

-- Tabla de Supervisores
CREATE TABLE Supervisor (
    supervisor_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_supervisor VARCHAR(20) UNIQUE NOT NULL,
    nombre_completo VARCHAR(100) NOT NULL,
    numero_identificacion VARCHAR(20) UNIQUE NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    zona_asignada INT,
    fecha_ingreso DATE NOT NULL DEFAULT CURRENT_DATE,
    estado ENUM('Activo', 'Inactivo') NOT NULL DEFAULT 'Activo',
    FOREIGN KEY (zona_asignada) REFERENCES Zona(zona_id) ON DELETE SET NULL
);

-- Tabla de Guardias
CREATE TABLE Guardia (
    guardia_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_guardia VARCHAR(20) UNIQUE NOT NULL,
    nombre_completo VARCHAR(100) NOT NULL,
    numero_identificacion VARCHAR(20) UNIQUE NOT NULL,
    fecha_ingreso DATE NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    email VARCHAR(100) UNIQUE,
    estado ENUM('Activo', 'Inactivo') NOT NULL DEFAULT 'Activo'
);

-- Tabla de Asignaciones
CREATE TABLE Asignacion (
    asignacion_id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_asignacion VARCHAR(20) UNIQUE NOT NULL,
    guardia_id INT NOT NULL,
    turno_id INT NOT NULL,
    zona_id INT NOT NULL,
    supervisor_id INT NOT NULL,
    fecha_asignacion DATE NOT NULL DEFAULT CURRENT_DATE,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE,
    estado ENUM('Activa', 'Completada', 'Cancelada') NOT NULL DEFAULT 'Activa',
    observaciones TEXT,
    FOREIGN KEY (guardia_id) REFERENCES Guardia(guardia_id) ON DELETE CASCADE,
    FOREIGN KEY (turno_id) REFERENCES Turno(turno_id) ON DELETE CASCADE,
    FOREIGN KEY (zona_id) REFERENCES Zona(zona_id) ON DELETE CASCADE,
    FOREIGN KEY (supervisor_id) REFERENCES Supervisor(supervisor_id) ON DELETE CASCADE
);

-- Tabla de Usuarios para autenticación
CREATE TABLE Usuario (
    usuario_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol ENUM('Administrador', 'Desarrollador', 'Supervisor') NOT NULL,
    nombre_completo VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso DATETIME,
    estado ENUM('Activo', 'Inactivo') NOT NULL DEFAULT 'Activo'
);

-- =====================================================
-- INSERTAR DATOS DE EJEMPLO
-- =====================================================

-- Insertar Clientes
INSERT INTO Cliente (codigo_cliente, nombre, direccion, telefono, email, fecha_registro) VALUES
('CLI001', 'Empresa ABC S.A.', 'Av. Principal 123, Ciudad', '022222222', 'contacto@empresaabc.com', '2023-01-15'),
('CLI002', 'Centro Comercial Plaza Mayor', 'Calle Norte 456, Ciudad', '023333333', 'seguridad@plazamayor.com', '2023-02-20'),
('CLI003', 'Hospital San José', 'Av. Sur 789, Ciudad', '024444444', 'admin@hospitalsanjose.com', '2023-03-10'),
('CLI004', 'Universidad Tecnológica', 'Calle Este 321, Ciudad', '025555555', 'rectoria@unitec.edu', '2023-04-05'),
('CLI005', 'Banco Nacional', 'Av. Oeste 654, Ciudad', '026666666', 'seguridad@bancodbnacional.com', '2023-05-12');

-- Insertar Servicios
INSERT INTO Servicio (codigo_servicio, nombre, descripcion, tarifa_mensual, cliente_id, fecha_contratacion) VALUES
('SER001', 'Vigilancia 24/7', 'Servicio de vigilancia continua las 24 horas del día', 5000.00, 1, '2023-01-20'),
('SER002', 'Monitoreo CCTV', 'Sistema de monitoreo con cámaras de seguridad', 3000.00, 2, '2023-02-25'),
('SER003', 'Escoltas Ejecutivos', 'Servicio de escoltas para ejecutivos', 8000.00, 1, '2023-03-15'),
('SER004', 'Control de Acceso', 'Control de entrada y salida de personal', 2500.00, 3, '2023-04-10'),
('SER005', 'Patrullaje Motorizado', 'Patrullaje en motocicletas por zonas específicas', 4000.00, 4, '2023-05-20'),
('SER006', 'Vigilancia Bancaria', 'Servicio especializado para entidades bancarias', 6000.00, 5, '2023-06-01');

-- Insertar Turnos
INSERT INTO Turno (codigo_turno, hora_inicio, hora_fin, tipo_turno, descripcion) VALUES
('TUR001', '06:00:00', '14:00:00', 'Diurno', 'Turno matutino'),
('TUR002', '14:00:00', '22:00:00', 'Diurno', 'Turno vespertino'),
('TUR003', '22:00:00', '06:00:00', 'Nocturno', 'Turno nocturno'),
('TUR004', '08:00:00', '16:00:00', 'Diurno', 'Turno administrativo'),
('TUR005', '16:00:00', '00:00:00', 'Nocturno', 'Turno tarde-noche'),
('TUR006', '00:00:00', '08:00:00', 'Nocturno', 'Turno madrugada');

-- Insertar Zonas
INSERT INTO Zona (codigo_zona, nombre, ubicacion, cliente_id, descripcion) VALUES
('ZON001', 'Edificio Principal', 'Av. Principal 123, Piso 1-10', 1, 'Edificio corporativo principal'),
('ZON002', 'Estacionamiento', 'Av. Principal 123, Nivel -1', 1, 'Estacionamiento subterráneo'),
('ZON003', 'Plaza Central', 'Calle Norte 456, Área comercial', 2, 'Área comercial principal'),
('ZON004', 'Emergencias', 'Av. Sur 789, Pabellón A', 3, 'Área de emergencias del hospital'),
('ZON005', 'Campus Norte', 'Calle Este 321, Bloque A-D', 4, 'Campus universitario norte'),
('ZON006', 'Sucursal Central', 'Av. Oeste 654, Nivel 1-3', 5, 'Sucursal bancaria principal');

-- Insertar Supervisores
INSERT INTO Supervisor (codigo_supervisor, nombre_completo, numero_identificacion, telefono, zona_asignada, fecha_ingreso) VALUES
('SUP001', 'Carlos Mendoza', '1234567890', '0912345678', 1, '2022-06-10'),
('SUP002', 'Ana Rodríguez', '0987654321', '0987654321', 2, '2022-08-15'),
('SUP003', 'Luis García', '1122334455', '0976543210', 3, '2022-09-20'),
('SUP004', 'María López', '2233445566', '0965432109', 4, '2022-11-05'),
('SUP005', 'Roberto Fernández', '3344556677', '0954321098', 5, '2023-01-15'),
('SUP006', 'Elena Martínez', '4455667788', '0943210987', 6, '2023-02-10');

-- Insertar Guardias
INSERT INTO Guardia (codigo_guardia, nombre_completo, numero_identificacion, fecha_ingreso, telefono, email) VALUES
('GUA001', 'Juan Pérez', '1111111111', '2022-01-15', '0911111111', 'juan.perez@seguridad.com'),
('GUA002', 'Pedro López', '2222222222', '2022-02-20', '0922222222', 'pedro.lopez@seguridad.com'),
('GUA003', 'Miguel Torres', '3333333333', '2022-03-10', '0933333333', 'miguel.torres@seguridad.com'),
('GUA004', 'Carlos Ruiz', '4444444444', '2022-04-05', '0944444444', 'carlos.ruiz@seguridad.com'),
('GUA005', 'Andrés Silva', '5555555555', '2022-05-12', '0955555555', 'andres.silva@seguridad.com'),
('GUA006', 'Diego Morales', '6666666666', '2022-06-18', '0966666666', 'diego.morales@seguridad.com'),
('GUA007', 'Fernando Castro', '7777777777', '2022-07-25', '0977777777', 'fernando.castro@seguridad.com'),
('GUA008', 'Ricardo Vargas', '8888888888', '2022-08-30', '0988888888', 'ricardo.vargas@seguridad.com'),
('GUA009', 'Oscar Herrera', '9999999999', '2022-09-05', '0999999999', 'oscar.herrera@seguridad.com'),
('GUA010', 'Hugo Jiménez', '0000000000', '2022-10-12', '0900000000', 'hugo.jimenez@seguridad.com');

-- Insertar Asignaciones
INSERT INTO Asignacion (codigo_asignacion, guardia_id, turno_id, zona_id, supervisor_id, fecha_asignacion, fecha_inicio, fecha_fin, estado) VALUES
('ASI001', 1, 1, 1, 1, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI002', 2, 2, 1, 1, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI003', 3, 3, 1, 1, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI004', 4, 1, 2, 2, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI005', 5, 2, 3, 3, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI006', 6, 3, 4, 4, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI007', 7, 1, 5, 5, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI008', 8, 2, 6, 6, '2023-01-20', '2023-01-21', NULL, 'Activa'),
('ASI009', 9, 3, 1, 1, '2023-01-20', '2023-01-22', NULL, 'Activa'),
('ASI010', 10, 1, 2, 2, '2023-01-20', '2023-01-22', NULL, 'Activa');

-- Insertar Usuarios del Sistema
-- Nota: Las contraseñas están hasheadas con password_hash('password', PASSWORD_DEFAULT)
INSERT INTO Usuario (username, password_hash, rol, nombre_completo, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador', 'Administrador del Sistema', 'admin@seguridad.com'),
('desarrollador', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Desarrollador', 'Desarrollador del Sistema', 'dev@seguridad.com'),
('supervisor', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Supervisor', 'Supervisor General', 'supervisor@seguridad.com'),
('admin2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador', 'Administrador Secundario', 'admin2@seguridad.com'),
('dev2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Desarrollador', 'Desarrollador Junior', 'dev2@seguridad.com');

-- =====================================================
-- CREAR USUARIOS DE MYSQL Y ASIGNAR PERMISOS
-- =====================================================

-- Crear usuarios de MySQL para la conexión de la aplicación
CREATE USER 'admin_seguridad'@'localhost' IDENTIFIED BY 'AdminSecure123!';
CREATE USER 'dev_seguridad'@'localhost' IDENTIFIED BY 'DevSecure456!';
CREATE USER 'supervisor_seguridad'@'localhost' IDENTIFIED BY 'SupervisorSecure789!';

-- Permisos para el Administrador
GRANT ALL PRIVILEGES ON SeguridadDB.* TO 'admin_seguridad'@'localhost' WITH GRANT OPTION;

-- Permisos para el Desarrollador
GRANT SELECT, INSERT, UPDATE, DELETE ON SeguridadDB.Guardia TO 'dev_seguridad'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON SeguridadDB.Asignacion TO 'dev_seguridad'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON SeguridadDB.Turno TO 'dev_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Cliente TO 'dev_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Servicio TO 'dev_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Zona TO 'dev_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Supervisor TO 'dev_seguridad'@'localhost';

-- Permisos para el Supervisor
GRANT SELECT ON SeguridadDB.Guardia TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Asignacion TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Turno TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Cliente TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Servicio TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Zona TO 'supervisor_seguridad'@'localhost';
GRANT SELECT ON SeguridadDB.Supervisor TO 'supervisor_seguridad'@'localhost';

-- Aplicar los cambios de privilegios
FLUSH PRIVILEGES;

-- =====================================================
-- MENSAJE DE CONFIRMACIÓN
-- =====================================================

SELECT 'Base de datos SeguridadDB creada exitosamente!' AS Mensaje;
SELECT 'Datos de ejemplo insertados correctamente.' AS Mensaje;
SELECT 'Usuarios de MySQL creados y permisos asignados.' AS Mensaje;
SELECT 'Vistas creadas para supervisores.' AS Mensaje;
SELECT 'Credenciales de prueba: admin/password, desarrollador/password, supervisor/password' AS Mensaje; 
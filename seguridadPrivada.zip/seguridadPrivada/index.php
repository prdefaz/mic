<?php
/**
 * Página Principal del Sistema de Seguridad Privada
 * Archivo: index.php
 * Descripción: Dashboard principal con menú dinámico según rol
 */

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir configuración
require_once 'config.php';

$username = $_SESSION['username'];
$rol = $_SESSION['rol'];
$nombreRol = obtenerNombreRol($rol);

// Obtener estadísticas básicas
$stats = [];
try {
    // Total de guardias
    $result = $conn->query("SELECT COUNT(*) as total FROM Guardia WHERE estado = 'Activo'");
    $stats['guardias_activos'] = $result->fetch_assoc()['total'];
    
    // Total de clientes
    $result = $conn->query("SELECT COUNT(*) as total FROM Cliente");
    $stats['total_clientes'] = $result->fetch_assoc()['total'];
    
    // Total de asignaciones activas
    $result = $conn->query("SELECT COUNT(*) as total FROM Asignacion WHERE estado = 'Activa'");
    $stats['asignaciones_activas'] = $result->fetch_assoc()['total'];
    
    // Total de servicios
    $result = $conn->query("SELECT COUNT(*) as total FROM Servicio");
    $stats['total_servicios'] = $result->fetch_assoc()['total'];
} catch (Exception $e) {
    // Si hay error, usar valores por defecto
    $stats = [
        'guardias_activos' => 0,
        'total_clientes' => 0,
        'asignaciones_activas' => 0,
        'total_servicios' => 0
    ];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Seguridad Privada</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #1e293b;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Header mejorado */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            color: #1e293b;
            padding: 15px 0;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header h1 {
            font-size: clamp(28px, 4vw, 36px);
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: none;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-details {
            text-align: right;
        }
        
        .user-details p {
            margin: 2px 0;
            font-size: 14px;
            color: #64748b;
        }
        
        .user-name {
            font-weight: 700;
            color: #1e293b !important;
            font-size: 16px !important;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 16px rgba(239, 68, 68, 0.3);
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(239, 68, 68, 0.4);
        }
        
        /* Container principal */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 30px;
        }
        
        /* Sección de bienvenida mejorada */
        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            padding: 50px 40px;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            margin-bottom: 50px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        }
        
        .welcome-section h2 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 20px;
            font-size: clamp(24px, 4vw, 36px);
            font-weight: 800;
        }
        
        .welcome-section p {
            color: #64748b;
            font-size: 18px;
            line-height: 1.7;
            max-width: 600px;
            margin: 0 auto;
        }
        
        /* Estadísticas mejoradas */
        .stats-section {
            margin-bottom: 50px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            padding: 30px 25px;
            border-radius: 20px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card:hover::before {
            transform: scaleX(1);
        }
        
        .stat-number {
            font-size: clamp(32px, 5vw, 48px);
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            display: block;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 16px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Menú mejorado */
        .menu-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            padding: 50px 40px;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .menu-section h3 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 35px;
            font-size: clamp(24px, 3vw, 32px);
            font-weight: 800;
            text-align: center;
        }
        
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
        }
        
        .menu-card {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            padding: 35px 30px;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
            transition: all 0.4s ease;
            text-decoration: none;
            color: inherit;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }
        
        .menu-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transform: scaleX(0);
            transition: transform 0.4s ease;
        }
        
        .menu-card:hover {
            transform: translateY(-12px) scale(1.02);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.15);
            border-color: rgba(102, 126, 234, 0.2);
        }
        
        .menu-card:hover::before {
            transform: scaleX(1);
        }
        
        .menu-card h4 {
            color: #1e293b;
            margin-bottom: 15px;
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .menu-card h4::before {
            content: '';
            width: 8px;
            height: 8px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: inline-block;
        }
        
        .menu-card p {
            color: #64748b;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .menu-card .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(102, 126, 234, 0.1);
        }
        
        .card-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-available {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
        }
        
        .status-restricted {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            color: white;
        }
        
                 .card-actions {
             display: flex;
             gap: 10px;
             align-items: center;
         }
         
         .btn-add,
         .btn-view {
             padding: 8px 16px;
             border: none;
             border-radius: 8px;
             font-size: 12px;
             font-weight: 600;
             cursor: pointer;
             text-decoration: none;
             transition: all 0.3s ease;
             text-align: center;
         }
         
         .btn-add {
             background: linear-gradient(135deg, #10b981 0%, #059669 100%);
             color: white;
             box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
         }
         
         .btn-add:hover {
             transform: translateY(-2px);
             box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
         }
         
         .btn-view {
             background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
             color: white;
             box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
         }
         
         .btn-view:hover {
             transform: translateY(-2px);
             box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
         }
        
        /* Responsive Design mejorado */
        @media (max-width: 1024px) {
            .container {
                padding: 30px 20px;
            }
            
            .welcome-section,
            .menu-section {
                padding: 40px 30px;
            }
            
            .menu-grid {
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 25px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
                padding: 0 20px;
            }
            
            .user-info {
                flex-direction: column;
                gap: 15px;
            }
            
            .user-details {
                text-align: center;
            }
            
            .container {
                padding: 20px 15px;
            }
            
            .welcome-section,
            .menu-section {
                padding: 30px 25px;
                border-radius: 20px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            
            .menu-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .menu-card {
                padding: 25px 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 10px 0;
            }
            
            .header h1 {
                font-size: 24px;
            }
            
            .welcome-section,
            .menu-section {
                padding: 25px 20px;
                border-radius: 16px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .stat-card {
                padding: 25px 20px;
            }
            
            .menu-card {
                padding: 20px 15px;
            }
            
            .menu-card h4 {
                font-size: 20px;
            }
        }
        
        /* Animaciones */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .welcome-section {
            animation: fadeInUp 0.8s ease-out;
        }
        
        .stats-grid {
            animation: fadeInUp 1s ease-out;
        }
        
        .menu-section {
            animation: fadeInUp 1.2s ease-out;
        }
        
        .stat-card:nth-child(1) { animation: fadeInUp 1.1s ease-out; }
        .stat-card:nth-child(2) { animation: fadeInUp 1.2s ease-out; }
        .stat-card:nth-child(3) { animation: fadeInUp 1.3s ease-out; }
        .stat-card:nth-child(4) { animation: fadeInUp 1.4s ease-out; }
        
        .menu-card:nth-child(1) { animation: fadeInUp 1.3s ease-out; }
        .menu-card:nth-child(2) { animation: fadeInUp 1.4s ease-out; }
        .menu-card:nth-child(3) { animation: fadeInUp 1.5s ease-out; }
        .menu-card:nth-child(4) { animation: fadeInUp 1.6s ease-out; }
        .menu-card:nth-child(5) { animation: fadeInUp 1.7s ease-out; }
        .menu-card:nth-child(6) { animation: fadeInUp 1.8s ease-out; }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>Sistema de Seguridad Privada</h1>
            <div class="user-info">
                <div class="user-details">
                    <p class="user-name"><?php echo htmlspecialchars($username); ?></p>
                    <p><?php echo htmlspecialchars($nombreRol); ?></p>
                </div>
                <a href="logout.php" class="logout-btn">Cerrar Sesión</a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome-section">
            <h2>Bienvenido al Dashboard</h2>
            <p>Gestiona eficientemente todos los aspectos de tu empresa de seguridad privada. Accede a las herramientas y reportes necesarios para mantener el control total de tus operaciones.</p>
        </div>
        
        <div class="stats-section">
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $stats['guardias_activos']; ?></span>
                    <div class="stat-label">Guardias Activos</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $stats['total_clientes']; ?></span>
                    <div class="stat-label">Clientes Registrados</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $stats['asignaciones_activas']; ?></span>
                    <div class="stat-label">Asignaciones Activas</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $stats['total_servicios']; ?></span>
                    <div class="stat-label">Servicios Disponibles</div>
                </div>
            </div>
        </div>
        
        <div class="menu-section">
            <h3>Panel de Control</h3>
            <div class="menu-grid">
                                 <?php if (tienePermiso($rol, 'R', 'Cliente')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Clientes</h4>
                     <p>Administra la información de empresas y clientes que contratan servicios de seguridad. Registra nuevos clientes y mantén actualizada su información.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <button onclick="abrirModal('modalCliente')" class="btn-add">+ Agregar</button>
                             <a href="crud_clientes.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Servicio')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Servicios</h4>
                     <p>Configura los diferentes tipos de servicios de seguridad ofrecidos. Define tarifas, descripciones y características de cada servicio.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <button onclick="abrirModal('modalServicio')" class="btn-add">+ Agregar</button>
                             <a href="crud_servicios.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Guardia')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Guardias</h4>
                     <p>Administra el personal de seguridad. Registra nuevos guardias, actualiza información personal y controla su estado laboral.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <button onclick="abrirModal('modalGuardia')" class="btn-add">+ Agregar</button>
                             <a href="crud_guardias.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Turno')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Turnos</h4>
                     <p>Configura los horarios de trabajo para el personal de seguridad. Define turnos diurnos, nocturnos y especiales según las necesidades.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <a href="crud_turnos.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Zona')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Zonas</h4>
                     <p>Administra las áreas geográficas donde se prestan servicios de seguridad. Define zonas de vigilancia y sus características.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <a href="crud_zonas.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Supervisor')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Supervisores</h4>
                     <p>Administra los supervisores responsables de coordinar los servicios de seguridad. Asigna responsabilidades y áreas de supervisión.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <a href="crud_supervisores.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if (tienePermiso($rol, 'R', 'Asignacion')): ?>
                 <div class="menu-card">
                     <h4>Gestionar Asignaciones</h4>
                     <p>Distribuye el personal de seguridad en turnos y zonas específicas. Optimiza la cobertura y eficiencia de los servicios.</p>
                     <div class="card-footer">
                         <span class="card-status status-available">Disponible</span>
                         <div class="card-actions">
                             <a href="crud_asignaciones.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
                
                                 <?php if ($rol == 'Administrador'): ?>
                 <div class="menu-card">
                     <h4>Gestionar Usuarios</h4>
                     <p>Administra los usuarios del sistema y sus permisos. Crea nuevos usuarios, asigna roles y controla el acceso al sistema.</p>
                     <div class="card-footer">
                         <span class="card-status status-restricted">Solo Admin</span>
                         <div class="card-actions">
                             <a href="crud_usuarios.php" class="btn-view">Ver Todos</a>
                         </div>
                     </div>
                 </div>
                 <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Modal para Agregar Cliente -->
    <div id="modalCliente" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Agregar Nuevo Cliente</h3>
                <span class="close" onclick="cerrarModal('modalCliente')">&times;</span>
            </div>
            <form id="formCliente" method="POST" action="procesar_cliente.php">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre_empresa">Nombre de la Empresa:</label>
                        <input type="text" id="nombre_empresa" name="nombre_empresa" required>
                    </div>
                    <div class="form-group">
                        <label for="ruc">RUC:</label>
                        <input type="text" id="ruc" name="ruc" required>
                    </div>
                    <div class="form-group">
                        <label for="direccion">Dirección:</label>
                        <input type="text" id="direccion" name="direccion" required>
                    </div>
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="contacto_principal">Contacto Principal:</label>
                        <input type="text" id="contacto_principal" name="contacto_principal" required>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">Guardar Cliente</button>
                    <button type="button" class="btn-secondary" onclick="cerrarModal('modalCliente')">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal para Agregar Guardia -->
    <div id="modalGuardia" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Agregar Nuevo Guardia</h3>
                <span class="close" onclick="cerrarModal('modalGuardia')">&times;</span>
            </div>
            <form id="formGuardia" method="POST" action="procesar_guardia.php">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="codigo_guardia">Código de Guardia:</label>
                        <input type="text" id="codigo_guardia" name="codigo_guardia" required>
                    </div>
                    <div class="form-group">
                        <label for="nombre_completo">Nombre Completo:</label>
                        <input type="text" id="nombre_completo" name="nombre_completo" required>
                    </div>
                    <div class="form-group">
                        <label for="numero_identificacion">Número de Identificación:</label>
                        <input type="text" id="numero_identificacion" name="numero_identificacion" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_ingreso">Fecha de Ingreso:</label>
                        <input type="date" id="fecha_ingreso" name="fecha_ingreso" required>
                    </div>
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">Guardar Guardia</button>
                    <button type="button" class="btn-secondary" onclick="cerrarModal('modalGuardia')">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal para Agregar Servicio -->
    <div id="modalServicio" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Agregar Nuevo Servicio</h3>
                <span class="close" onclick="cerrarModal('modalServicio')">&times;</span>
            </div>
            <form id="formServicio" method="POST" action="procesar_servicio.php">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre_servicio">Nombre del Servicio:</label>
                        <input type="text" id="nombre_servicio" name="nombre_servicio" required>
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripción:</label>
                        <textarea id="descripcion" name="descripcion" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="tarifa_mensual">Tarifa Mensual:</label>
                        <input type="number" id="tarifa_mensual" name="tarifa_mensual" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select id="estado" name="estado" required>
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                        </select>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">Guardar Servicio</button>
                    <button type="button" class="btn-secondary" onclick="cerrarModal('modalServicio')">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Estilos para los modales -->
    <style>
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease-out;
        }

        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 0;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideIn 0.3s ease-out;
        }

        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 30px;
            border-radius: 20px 20px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .close:hover {
            transform: scale(1.1);
        }

        .modal form {
            padding: 30px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 15px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1f2937;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            padding-top: 20px;
            border-top: 1px solid rgba(102, 126, 234, 0.1);
        }

        .btn-primary,
        .btn-secondary {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 15px;
            font-family: inherit;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%);
            color: white;
            box-shadow: 0 4px 16px rgba(107, 114, 128, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(107, 114, 128, 0.4);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: 20px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
        }
    </style>

    <!-- JavaScript para los modales -->
    <script>
        function abrirModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function cerrarModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Cerrar modal al hacer clic fuera del contenido
        window.onclick = function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });
        }

        // Manejar envío de formularios
        document.addEventListener('DOMContentLoaded', function() {
            const forms = ['formCliente', 'formGuardia', 'formServicio'];
            
            forms.forEach(formId => {
                const form = document.getElementById(formId);
                if (form) {
                    form.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        const formData = new FormData(form);
                        const action = form.action;
                        
                        fetch(action, {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert(data.message);
                                form.reset();
                                cerrarModal(formId.replace('form', 'modal'));
                                // Recargar la página para actualizar estadísticas
                                location.reload();
                            } else {
                                alert('Error: ' + data.message);
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Error al procesar la solicitud');
                        });
                    });
                }
            });
        });
    </script>
</body>
</html> 
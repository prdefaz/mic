<?php
/**
 * CRUD de Guardias - Sistema de Seguridad Privada
 * Archivo: crud_guardias.php
 * Descripción: Gestión completa de guardias de seguridad
 */

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir configuración
require_once 'config.php';

$rol = $_SESSION['rol'];

// Verificar permisos
if (!tienePermiso($rol, 'R', 'Guardia')) {
    header("Location: index.php");
    exit();
}

$mensaje = '';
$tipo_mensaje = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {
            case 'crear':
                if (tienePermiso($rol, 'C', 'Guardia')) {
                    $codigo = limpiarDatos($_POST['codigo_guardia']);
                    $nombre = limpiarDatos($_POST['nombre_completo']);
                    $identificacion = limpiarDatos($_POST['numero_identificacion']);
                    $fecha_ingreso = limpiarDatos($_POST['fecha_ingreso']);
                    $telefono = limpiarDatos($_POST['telefono']);
                    $email = limpiarDatos($_POST['email']);
                    
                    $sql = "INSERT INTO Guardia (codigo_guardia, nombre_completo, numero_identificacion, fecha_ingreso, telefono, email) 
                            VALUES ('$codigo', '$nombre', '$identificacion', '$fecha_ingreso', '$telefono', '$email')";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Guardia creado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al crear guardia: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'actualizar':
                if (tienePermiso($rol, 'U', 'Guardia')) {
                    $id = limpiarDatos($_POST['guardia_id']);
                    $codigo = limpiarDatos($_POST['codigo_guardia']);
                    $nombre = limpiarDatos($_POST['nombre_completo']);
                    $identificacion = limpiarDatos($_POST['numero_identificacion']);
                    $fecha_ingreso = limpiarDatos($_POST['fecha_ingreso']);
                    $telefono = limpiarDatos($_POST['telefono']);
                    $email = limpiarDatos($_POST['email']);
                    $estado = limpiarDatos($_POST['estado']);
                    
                    $sql = "UPDATE Guardia SET 
                            codigo_guardia = '$codigo',
                            nombre_completo = '$nombre',
                            numero_identificacion = '$identificacion',
                            fecha_ingreso = '$fecha_ingreso',
                            telefono = '$telefono',
                            email = '$email',
                            estado = '$estado'
                            WHERE guardia_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Guardia actualizado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al actualizar guardia: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'eliminar':
                if (tienePermiso($rol, 'D', 'Guardia')) {
                    $id = limpiarDatos($_POST['guardia_id']);
                    
                    $sql = "DELETE FROM Guardia WHERE guardia_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Guardia eliminado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al eliminar guardia: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
        }
    }
}

// Obtener datos para editar
$guardia_editar = null;
if (isset($_GET['editar']) && tienePermiso($rol, 'U', 'Guardia')) {
    $id = limpiarDatos($_GET['editar']);
    $result = $conn->query("SELECT * FROM Guardia WHERE guardia_id = $id");
    if ($result->num_rows > 0) {
        $guardia_editar = $result->fetch_assoc();
    }
}

// Obtener lista de guardias
$sql = "SELECT * FROM Guardia ORDER BY nombre_completo";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Guardias - Sistema de Seguridad</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>👮 Gestionar Guardias</h1>
            <a href="index.php" class="back-btn">← Volver al Dashboard</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
        <?php endif; ?>
        
        <?php if (tienePermiso($rol, 'C', 'Guardia') || tienePermiso($rol, 'U', 'Guardia')): ?>
        <div class="form-section">
            <h2><?php echo $guardia_editar ? 'Editar Guardia' : 'Crear Nuevo Guardia'; ?></h2>
            <form method="POST">
                <input type="hidden" name="accion" value="<?php echo $guardia_editar ? 'actualizar' : 'crear'; ?>">
                <?php if ($guardia_editar): ?>
                <input type="hidden" name="guardia_id" value="<?php echo $guardia_editar['guardia_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="codigo_guardia">Código de Guardia:</label>
                        <input type="text" id="codigo_guardia" name="codigo_guardia" 
                               value="<?php echo $guardia_editar ? htmlspecialchars($guardia_editar['codigo_guardia']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="nombre_completo">Nombre Completo:</label>
                        <input type="text" id="nombre_completo" name="nombre_completo" 
                               value="<?php echo $guardia_editar ? htmlspecialchars($guardia_editar['nombre_completo']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="numero_identificacion">Número de Identificación:</label>
                        <input type="text" id="numero_identificacion" name="numero_identificacion" 
                               value="<?php echo $guardia_editar ? htmlspecialchars($guardia_editar['numero_identificacion']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_ingreso">Fecha de Ingreso:</label>
                        <input type="date" id="fecha_ingreso" name="fecha_ingreso" 
                               value="<?php echo $guardia_editar ? $guardia_editar['fecha_ingreso'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" 
                               value="<?php echo $guardia_editar ? htmlspecialchars($guardia_editar['telefono']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo $guardia_editar ? htmlspecialchars($guardia_editar['email']) : ''; ?>">
                    </div>
                    
                    <?php if ($guardia_editar): ?>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select id="estado" name="estado" required>
                            <option value="Activo" <?php echo $guardia_editar['estado'] == 'Activo' ? 'selected' : ''; ?>>Activo</option>
                            <option value="Inactivo" <?php echo $guardia_editar['estado'] == 'Inactivo' ? 'selected' : ''; ?>>Inactivo</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div style="margin-top: 20px;">
                    <button type="submit" class="btn-primary">
                        <?php echo $guardia_editar ? 'Actualizar Guardia' : 'Crear Guardia'; ?>
                    </button>
                    <?php if ($guardia_editar): ?>
                    <a href="crud_guardias.php" class="btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="table-section">
            <h2>Lista de Guardias</h2>
            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre Completo</th>
                        <th>Identificación</th>
                        <th>Fecha Ingreso</th>
                        <th>Teléfono</th>
                        <th>Email</th>
                        <th>Estado</th>
                        <?php if (tienePermiso($rol, 'U', 'Guardia') || tienePermiso($rol, 'D', 'Guardia')): ?>
                        <th>Acciones</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['codigo_guardia']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_completo']); ?></td>
                            <td><?php echo htmlspecialchars($row['numero_identificacion']); ?></td>
                            <td><?php echo $row['fecha_ingreso']; ?></td>
                            <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($row['estado']); ?>">
                                    <?php echo $row['estado']; ?>
                                </span>
                            </td>
                            <?php if (tienePermiso($rol, 'U', 'Guardia') || tienePermiso($rol, 'D', 'Guardia')): ?>
                            <td>
                                <div class="action-buttons">
                                    <?php if (tienePermiso($rol, 'U', 'Guardia')): ?>
                                    <a href="?editar=<?php echo $row['guardia_id']; ?>" class="btn-secondary btn-small">Editar</a>
                                    <?php endif; ?>
                                    <?php if (tienePermiso($rol, 'D', 'Guardia')): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('¿Está seguro de eliminar este guardia?');">
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="guardia_id" value="<?php echo $row['guardia_id']; ?>">
                                        <button type="submit" class="btn-danger btn-small">Eliminar</button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: #666;">No hay guardias registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

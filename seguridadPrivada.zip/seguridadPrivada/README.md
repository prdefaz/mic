# Sistema de Gestión para Empresa de Seguridad Privada

## Descripción

Sistema distribuido basado en microservicios para la gestión de una empresa de seguridad privada. El sistema permite administrar guardias, clientes, servicios contratados, turnos de trabajo, supervisores, zonas de vigilancia y asignaciones.

## Características Principales

- **Arquitectura de Microservicios**: APIs REST independientes para cada entidad
- **Sistema de Roles**: Administrador, Desarrollador y Supervisor con permisos específicos
- **Interfaz Web Moderna**: Dashboard con diseño responsive y colores verde esmeralda/dorado
- **Base de Datos Relacional**: MySQL con integridad referencial
- **Seguridad**: Autenticación y autorización por roles
- **API REST**: Microservicios completos para operaciones CRUD
- **Diseño Responsive**: Optimizado para dispositivos móviles y tablets
- **Sin Iconos**: Interfaz limpia sin dependencias de iconos externos

## Estructura del Proyecto

```
SistemaBancario/
├── API/                          # Microservicios
│   ├── api_guardias.php         # API REST para guardias
│   ├── api_clientes.php         # API REST para clientes
│   ├── api_servicios.php        # API REST para servicios
│   ├── api_asignaciones.php     # API REST para asignaciones
│   ├── formulario_guardias.html # Interfaz de consumo del API
│   ├── formulario_clientes.html # Interfaz de consumo del API
│   ├── formulario_asignaciones.html # Interfaz de consumo del API
│   ├── style.css                # Estilos para APIs
│   └── script.js                # JavaScript para APIs
├── config.php                   # Configuración de base de datos
├── index.php                    # Dashboard principal
├── login.php                    # Sistema de autenticación
├── logout.php                   # Cerrar sesión
├── styles.css                   # Estilos comunes del sistema
├── crud_guardias.php           # CRUD de guardias (interfaz web)
├── crud_clientes.php           # CRUD de clientes
├── crud_servicios.php          # CRUD de servicios
├── crud_turnos.php             # CRUD de turnos
├── crud_zonas.php              # CRUD de zonas
├── crud_supervisores.php       # CRUD de supervisores
├── crud_asignaciones.php       # CRUD de asignaciones
├── crud_usuarios.php           # CRUD de usuarios
├── script_base_datos.sql       # Script de base de datos
└── README.md                   # Documentación
```

## Base de Datos

### Tablas Principales

1. **Cliente**: Información de empresas que contratan servicios
2. **Servicio**: Tipos de servicios ofrecidos (vigilancia, monitoreo, etc.)
3. **Turno**: Horarios de trabajo (diurno/nocturno)
4. **Zona**: Zonas geográficas donde se prestan servicios
5. **Supervisor**: Supervisores responsables de coordinar servicios
6. **Guardia**: Guardias de seguridad
7. **Asignacion**: Asignaciones de guardias a turnos y zonas
8. **Usuario**: Usuarios del sistema con roles

### Script de Base de Datos

Ejecutar `script_base_datos.sql` para crear:
- Base de datos `SeguridadDB`
- Todas las tablas con relaciones
- Datos de ejemplo
- Usuarios con permisos específicos
- Vistas para supervisores

## Instalación

### Requisitos

- XAMPP (Apache + MySQL + PHP)
- PHP 7.4 o superior
- MySQL 5.7 o superior

### Pasos de Instalación

1. **Clonar el proyecto**:
   ```bash
   git clone <repository-url>
   cd SistemaBancario
   ```

2. **Configurar XAMPP**:
   - Iniciar Apache y MySQL
   - Colocar el proyecto en `htdocs/`

3. **Crear la base de datos**:
   - Abrir phpMyAdmin
   - Ejecutar `script_base_datos.sql`

4. **Configurar conexión**:
   - Editar `config.php` si es necesario
   - Verificar credenciales de MySQL

5. **Acceder al sistema**:
   - URL: `http://localhost/SistemaBancario/`
   - Credenciales por defecto:
     - Usuario: `admin` / Contraseña: `password`
     - Usuario: `desarrollador` / Contraseña: `password`
     - Usuario: `supervisor` / Contraseña: `password`

## Microservicios

## Microservicios Implementados

### API de Guardias
**Endpoint**: `/API/api_guardias.php`
**Interfaz**: `/API/formulario_guardias.html`

### API de Clientes
**Endpoint**: `/API/api_clientes.php`
**Interfaz**: `/API/formulario_clientes.html`

### API de Servicios
**Endpoint**: `/API/api_servicios.php`

### API de Asignaciones
**Endpoint**: `/API/api_asignaciones.php`
**Interfaz**: `/API/formulario_asignaciones.html`

**Métodos disponibles en todos los microservicios**:
- `GET` - Obtener todos los registros o uno específico
- `POST` - Crear nuevo registro
- `PUT` - Actualizar registro existente
- `DELETE` - Eliminar registro

**Ejemplo de uso para Guardias**:
```bash
# Obtener todos los guardias
curl -X GET http://localhost/SistemaBancario/API/api_guardias.php

# Crear nuevo guardia
curl -X POST http://localhost/SistemaBancario/API/api_guardias.php \
  -H "Content-Type: application/json" \
  -d '{
    "codigo_guardia": "GUA011",
    "nombre_completo": "Juan Pérez",
    "numero_identificacion": "1234567890",
    "fecha_ingreso": "2023-01-15",
    "telefono": "0912345678",
    "email": "juan.perez@seguridad.com"
  }'
```

### Interfaces de Consumo

Cada microservicio tiene su interfaz web correspondiente para pruebas y gestión:
- `/API/formulario_guardias.html` - Gestión de guardias
- `/API/formulario_clientes.html` - Gestión de clientes  
- `/API/formulario_asignaciones.html` - Gestión de asignaciones

## Roles y Permisos

### Administrador
- Acceso completo a todas las tablas
- Operaciones CRUD en todas las entidades
- Gestión de usuarios y roles

### Desarrollador
- Acceso a guardias, asignaciones y turnos
- Solo lectura en clientes, servicios, zonas y supervisores
- Pruebas de algoritmos y funcionalidades

### Supervisor
- Solo operaciones de lectura (SELECT)
- Acceso a vistas predefinidas
- Consultas de reportes y estadísticas

## Funcionalidades

### Dashboard Principal
- Estadísticas en tiempo real
- Menú dinámico según rol
- Acceso rápido a todas las funciones
- Diseño responsive con colores verde esmeralda y dorado

### Gestión de Entidades
- **Clientes**: Registro de empresas contratantes
- **Servicios**: Tipos de servicios y tarifas
- **Guardias**: Personal de seguridad
- **Turnos**: Horarios de trabajo
- **Zonas**: Áreas de vigilancia
- **Supervisores**: Coordinadores de servicios
- **Asignaciones**: Distribución de personal

### Reportes y Vistas
- Asignaciones activas
- Guardias por zona
- Servicios por cliente
- Estadísticas generales

### Características de Diseño
- **Colores**: Verde esmeralda (#059669) y dorado (#f59e0b)
- **Responsive**: Optimizado para móviles, tablets y desktop
- **Sin Iconos**: Interfaz limpia sin dependencias externas
- **Animaciones**: Transiciones suaves y efectos hover
- **Accesibilidad**: Contraste adecuado y navegación por teclado

## Seguridad

- **Autenticación**: Sistema de login con sesiones
- **Autorización**: Control de acceso por roles
- **Validación**: Sanitización de datos de entrada
- **Integridad**: Claves foráneas y restricciones

## Conectividad de Red

### Configuración OSPF
- Protocolo de enrutamiento OSPF área única
- Número de proceso 35
- Configuración automática con Ansible

### Ansible (Infrastructure as Code)
- Configuración de routers R2, R3, R4, R5
- Archivo de inventario (Hosts)
- Playbook en YAML
- Comunicación SSHv2 segura

## Desarrollo

### Estructura de Archivos CRUD
Cada entidad tiene su archivo CRUD con:
- Formularios de creación/edición
- Tablas de listado
- Validación de permisos
- Mensajes de confirmación

### Estándares de Código
- PHP 7.4+ con mysqli
- HTML5 semántico
- CSS3 con diseño responsive y Grid/Flexbox
- JavaScript ES6+ con async/await
- SQL con prepared statements
- Arquitectura de microservicios REST

## Mantenimiento

### Backup de Base de Datos
```bash
mysqldump -u root -p SeguridadDB > backup_seguridad.sql
```

### Logs y Monitoreo
- Revisar logs de Apache en XAMPP
- Monitorear conexiones a la base de datos
- Verificar permisos de archivos

## Soporte

Para soporte técnico o consultas:
- Revisar la documentación en línea
- Verificar logs del sistema
- Contactar al equipo de desarrollo

## Licencia

Este proyecto está desarrollado para fines educativos y de demostración.

---

**Desarrollado para ESPE DCCO - 202550**

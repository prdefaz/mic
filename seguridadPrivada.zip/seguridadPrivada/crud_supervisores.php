<?php
/**
 * CRUD de Supervisores - Sistema de Seguridad Privada
 * Archivo: crud_supervisores.php
 * Descripción: Gestión completa de supervisores
 */

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir configuración
require_once 'config.php';

$rol = $_SESSION['rol'];

// Verificar permisos
if (!tienePermiso($rol, 'R', 'Supervisor')) {
    header("Location: index.php");
    exit();
}

$mensaje = '';
$tipo_mensaje = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {
            case 'crear':
                if (tienePermiso($rol, 'C', 'Supervisor')) {
                    $codigo = limpiarDatos($_POST['codigo_supervisor']);
                    $nombre = limpiarDatos($_POST['nombre_completo']);
                    $identificacion = limpiarDatos($_POST['numero_identificacion']);
                    $telefono = limpiarDatos($_POST['telefono']);
                    $zona_asignada = limpiarDatos($_POST['zona_asignada']);
                    
                    $sql = "INSERT INTO Supervisor (codigo_supervisor, nombre_completo, numero_identificacion, telefono, zona_asignada) 
                            VALUES ('$codigo', '$nombre', '$identificacion', '$telefono', $zona_asignada)";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Supervisor creado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al crear supervisor: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'actualizar':
                if (tienePermiso($rol, 'U', 'Supervisor')) {
                    $id = limpiarDatos($_POST['supervisor_id']);
                    $codigo = limpiarDatos($_POST['codigo_supervisor']);
                    $nombre = limpiarDatos($_POST['nombre_completo']);
                    $identificacion = limpiarDatos($_POST['numero_identificacion']);
                    $telefono = limpiarDatos($_POST['telefono']);
                    $zona_asignada = limpiarDatos($_POST['zona_asignada']);
                    $estado = limpiarDatos($_POST['estado']);
                    
                    $sql = "UPDATE Supervisor SET 
                            codigo_supervisor = '$codigo',
                            nombre_completo = '$nombre',
                            numero_identificacion = '$identificacion',
                            telefono = '$telefono',
                            zona_asignada = $zona_asignada,
                            estado = '$estado'
                            WHERE supervisor_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Supervisor actualizado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al actualizar supervisor: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
                
            case 'eliminar':
                if (tienePermiso($rol, 'D', 'Supervisor')) {
                    $id = limpiarDatos($_POST['supervisor_id']);
                    
                    $sql = "DELETE FROM Supervisor WHERE supervisor_id = $id";
                    
                    if ($conn->query($sql) === TRUE) {
                        $mensaje = "Supervisor eliminado exitosamente";
                        $tipo_mensaje = "success";
                    } else {
                        $mensaje = "Error al eliminar supervisor: " . $conn->error;
                        $tipo_mensaje = "error";
                    }
                }
                break;
        }
    }
}

// Obtener datos para editar
$supervisor_editar = null;
if (isset($_GET['editar']) && tienePermiso($rol, 'U', 'Supervisor')) {
    $id = limpiarDatos($_GET['editar']);
    $result = $conn->query("SELECT * FROM Supervisor WHERE supervisor_id = $id");
    if ($result->num_rows > 0) {
        $supervisor_editar = $result->fetch_assoc();
    }
}

// Obtener lista de zonas para el select
$zonas_result = $conn->query("SELECT zona_id, nombre FROM Zona WHERE estado = 'Activo' ORDER BY nombre");

// Obtener lista de supervisores
$sql = "SELECT s.*, z.nombre as zona_nombre 
        FROM Supervisor s 
        LEFT JOIN Zona z ON s.zona_asignada = z.zona_id 
        ORDER BY s.nombre_completo";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Supervisores - Sistema de Seguridad</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            color: #333;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }
        
        .back-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        
        .form-group input, .form-group select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #2c3e50;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.3s ease;
        }
        
        .btn-primary {
            background: #2c3e50;
            color: white;
        }
        
        .btn-primary:hover {
            background: #34495e;
        }
        
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .table-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .table-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .status-active {
            color: #27ae60;
            font-weight: 600;
        }
        
        .status-inactive {
            color: #e74c3c;
            font-weight: 600;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }
        
        .mensaje {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .mensaje.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .mensaje.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .zone-assigned {
            font-weight: 600;
            color: #3498db;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>👨‍💼 Gestionar Supervisores</h1>
            <a href="index.php" class="back-btn">← Volver al Dashboard</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
        <?php endif; ?>
        
        <?php if (tienePermiso($rol, 'C', 'Supervisor') || tienePermiso($rol, 'U', 'Supervisor')): ?>
        <div class="form-section">
            <h2><?php echo $supervisor_editar ? 'Editar Supervisor' : 'Crear Nuevo Supervisor'; ?></h2>
            <form method="POST">
                <input type="hidden" name="accion" value="<?php echo $supervisor_editar ? 'actualizar' : 'crear'; ?>">
                <?php if ($supervisor_editar): ?>
                <input type="hidden" name="supervisor_id" value="<?php echo $supervisor_editar['supervisor_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="codigo_supervisor">Código de Supervisor:</label>
                        <input type="text" id="codigo_supervisor" name="codigo_supervisor" 
                               value="<?php echo $supervisor_editar ? htmlspecialchars($supervisor_editar['codigo_supervisor']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="nombre_completo">Nombre Completo:</label>
                        <input type="text" id="nombre_completo" name="nombre_completo" 
                               value="<?php echo $supervisor_editar ? htmlspecialchars($supervisor_editar['nombre_completo']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="numero_identificacion">Número de Identificación:</label>
                        <input type="text" id="numero_identificacion" name="numero_identificacion" 
                               value="<?php echo $supervisor_editar ? htmlspecialchars($supervisor_editar['numero_identificacion']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" 
                               value="<?php echo $supervisor_editar ? htmlspecialchars($supervisor_editar['telefono']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="zona_asignada">Zona Asignada:</label>
                        <select id="zona_asignada" name="zona_asignada" required>
                            <option value="">Seleccionar zona</option>
                            <?php while($zona = $zonas_result->fetch_assoc()): ?>
                            <option value="<?php echo $zona['zona_id']; ?>" 
                                    <?php echo ($supervisor_editar && $supervisor_editar['zona_asignada'] == $zona['zona_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($zona['nombre']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <?php if ($supervisor_editar): ?>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select id="estado" name="estado" required>
                            <option value="Activo" <?php echo $supervisor_editar['estado'] == 'Activo' ? 'selected' : ''; ?>>Activo</option>
                            <option value="Inactivo" <?php echo $supervisor_editar['estado'] == 'Inactivo' ? 'selected' : ''; ?>>Inactivo</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div style="margin-top: 20px;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $supervisor_editar ? 'Actualizar Supervisor' : 'Crear Supervisor'; ?>
                    </button>
                    <?php if ($supervisor_editar): ?>
                    <a href="crud_supervisores.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="table-section">
            <h2>Lista de Supervisores</h2>
            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre Completo</th>
                        <th>Identificación</th>
                        <th>Teléfono</th>
                        <th>Zona Asignada</th>
                        <th>Fecha Ingreso</th>
                        <th>Estado</th>
                        <?php if (tienePermiso($rol, 'U', 'Supervisor') || tienePermiso($rol, 'D', 'Supervisor')): ?>
                        <th>Acciones</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['codigo_supervisor']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_completo']); ?></td>
                            <td><?php echo htmlspecialchars($row['numero_identificacion']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                            <td class="zone-assigned"><?php echo htmlspecialchars($row['zona_nombre']); ?></td>
                            <td><?php echo $row['fecha_ingreso']; ?></td>
                            <td>
                                <span class="status-<?php echo strtolower($row['estado']); ?>">
                                    <?php echo $row['estado']; ?>
                                </span>
                            </td>
                            <?php if (tienePermiso($rol, 'U', 'Supervisor') || tienePermiso($rol, 'D', 'Supervisor')): ?>
                            <td>
                                <div class="action-buttons">
                                    <?php if (tienePermiso($rol, 'U', 'Supervisor')): ?>
                                    <a href="?editar=<?php echo $row['supervisor_id']; ?>" class="btn btn-secondary btn-small">Editar</a>
                                    <?php endif; ?>
                                    <?php if (tienePermiso($rol, 'D', 'Supervisor')): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('¿Está seguro de eliminar este supervisor?');">
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="supervisor_id" value="<?php echo $row['supervisor_id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-small">Eliminar</button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: #666;">No hay supervisores registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
